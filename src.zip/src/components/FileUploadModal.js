import React, { useState } from "react";
import Modal from "react-modal";

import { Pie } from "react-chartjs-2"; // Import Pie chart
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";

// Register chart components
ChartJS.register(ArcElement, Tooltip, Legend);

// Set Modal root element
Modal.setAppElement("#root");

const FileUploadModal = ({ isOpen, onClose, onFileUpload, fileData, currentStep, setCurrentStep, fileName,handleImport }) => {
 
    const [selectedColumn, setSelectedColumn] = useState(null); // Define state for selectedColumn

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onClose}
      contentLabel="Upload File"
      style={{
        content: {
          width: "1100px",
          height: "550px",
          margin: "auto",
          borderRadius: "10px",
          padding: "0",
          boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
          display: "flex",
          flexDirection: "column",
          position: "relative",
          marginTop:"50px",
          zIndex:100
        },
      }}
    >
      {/* Header */}
      <div
        style={{
          position: "absolute",
          top: "0",
          left: "0",
          width: "100%",
          background: "#fff",
          padding: "15px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "1px solid #ddd",
          zIndex: "1000",
        }}
      >
        {currentStep > 1 && (
          <button className="btn btn-secondary" onClick={() => setCurrentStep(currentStep - 1)}>
            ⬅ Back
          </button>
        )}
        <button
          onClick={onClose}
          style={{
            fontSize: "20px",
            border: "none",
            background: "none",
            cursor: "pointer",
            position: "absolute",
            right: "15px",
            top: "10px",
          }}
        >
          ✖
        </button>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, padding: "70px 20px 70px", overflowY: "auto" }}>
        {/* Step 1: File Selection */}
        {currentStep === 1 && (
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-400 p-6 rounded-lg cursor-pointer">
            <label className="cursor-pointer">
              <input type="file" className="hidden" accept=".csv, .xlsx, .xls" onChange={onFileUpload} />
              <div className="text-center text-gray-600">📁 Click to upload CSV or Excel file</div>
            </label>
          </div>
        )}

        {/* Step 2: File Preview */}
        {currentStep === 2 && (
          <>
            <h2 className="text-xl font-bold text-center mb-4">Preview File: {fileName}</h2>
            <div className="max-h-40 overflow-y-auto border rounded p-2">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    {Object.keys(fileData[0] || {}).map((key) => (
                      <th key={key} className="border p-2">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {fileData.map((row, index) => (
                    <tr key={index} className="border">
                      {Object.values(row).map((cell, idx) => (
                        <td key={idx} className="border p-2">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

      {/* Step 3: Import Complete */}

      {currentStep === 3 && (
  <div className="flex flex-col items-center space-y-6">
    {/* Column Selection */}
    <div className="w-full p-4 border-b">
      <h3 className="text-lg font-bold mb-2">Select a Column</h3>
      <ul className="flex space-x-4">
        {Object.keys(fileData[0] || {}).map((key, index) => (
          <li 
            key={index} 
            className="text-gray-700 cursor-pointer hover:text-blue-500 px-3 py-1 border rounded"
            onClick={() => setSelectedColumn(key)}
          >
            {key}
          </li>
        ))}
      </ul>
    </div>

    {/* Parent Wrapper for Row Layout */}
    <div className="flex w-full p-4 border space-x-6">
      {/* Selected Column */}
      <div className="flex-1 border p-4">
        <h3 className="text-lg font-bold mb-2">Selected Column</h3>
        <p className="text-gray-700">{selectedColumn}</p>
      </div>

      {/* Pie Chart (Smaller Size) */}
      <div className="flex-1 border p-4 flex justify-center items-center">
        {selectedColumn && (
          <div className="w-40 h-40">
            <h3 className="text-lg font-bold mb-2 text-center">Pie Chart</h3>
            <Pie data={{
              labels: [...new Set(fileData.map(row => row[selectedColumn]))],
              datasets: [{
                data: Object.values(fileData.reduce((acc, row) => {
                  acc[row[selectedColumn]] = (acc[row[selectedColumn]] || 0) + 1;
                  return acc;
                }, {})),
                backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4CAF50", "#8E44AD"],
              }]
            }} />
          </div>
        )}
      </div>

      {/* Selected Column Data */}
      <div className="flex-1 border p-4">
        <h3 className="text-lg font-bold mb-2">Selected Data</h3>
        <div className="flex flex-wrap gap-2">
          {selectedColumn && fileData.map((row, index) => (
            <span key={index} className="text-gray-600 px-2 py-1 border rounded">{row[selectedColumn]}</span>
          ))}
        </div>
      </div>
    </div>
  </div>
)}

      </div>

      {/* Footer */}
      <div
        style={{
          position: "absolute",
          bottom: "0",
          left: "0",
          width: "100%",
          background: "#fff",
          padding: "15px",
          display: "flex",
          justifyContent: "center",
          borderTop: "1px solid #ddd",
          zIndex: "1000",
        }}
      >
        {currentStep === 2 && (
  <button className="btn btn-success w-full" onClick={() => handleImport(fileData)}>
         Import
       </button>
       
        )}
        {currentStep === 3 && (
          <button className="btn btn-primary w-full" onClick={onClose}>
            Done
          </button>
        )}
      </div>
    </Modal>
  );
};

export default FileUploadModal;
